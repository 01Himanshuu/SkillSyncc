#include <stdio.h>

void worstFit(int blockSize[], int m, int processSize[], int n) {
int allocation[n]; // Stores block allocated to each process
int fragment[n];   // Stores the remaining fragment after allocation

// Initially, no block is assigned to any process
for (int i = 0; i < n; i++) {
allocation[i] = -1;
fragment[i] = -1;
}

// Pick each process and find the largest suitable block
for (int i = 0; i < n; i++) {
int worstIdx = -1;
for (int j = 0; j < m; j++) {
if (blockSize[j] >= processSize[i]) {
if (worstIdx == -1 || blockSize[j] > blockSize[worstIdx]) {
worstIdx = j;
}
}
}

// If a block is found, allocate it to the process
if (worstIdx != -1) {
allocation[i] = worstIdx;
fragment[i] = blockSize[worstIdx] - processSize[i];
blockSize[worstIdx] -= processSize[i];
}
}

// Output results
printf("Process_no:\tProcess_size:\tBlock_no:\tBlock_size:\tFragment\n");
for (int i = 0; i < n; i++) {
printf("%d\t%d\t", i, processSize[i]);
if (allocation[i] != -1)
printf("%d\t%d\t%d\n", allocation[i], processSize[i] + fragment[i], fragment[i]);
else
printf("Not Allocated\n");
}
}

int main() {
int m, n;

// Input number of blocks
scanf("%d", &m);
int blockSize[m];
for (int i = 0; i < m; i++) {
scanf("%d", &blockSize[i]);
}

// Input number of processes
scanf("%d", &n);
int processSize[n];
for (int i = 0; i < n; i++) {
scanf("%d", &processSize[i]);
}

// Apply Worst Fit Algorithm
worstFit(blockSize, m, processSize, n);

return 0;
}
